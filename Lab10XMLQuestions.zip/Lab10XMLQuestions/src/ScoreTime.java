/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hrai36
 */
public class ScoreTime {
    private String Ranking;
    private String Time;
    
    public ScoreTime(){
        
    }
    
     public String getRanking() {
        return Ranking;
    }

    
    public void setRanking(String Ranking) {
        this.Ranking = Ranking;
    }
    public String getTime() {
        return Time;
    }

    
    public void setTime(String Time) {
        this.Time = Time;
    }
    
    
    
    
    
    
}

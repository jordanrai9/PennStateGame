import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

public class myJFramex extends JFrame
{

    myJPanelx px;

    public myJFramex()
    {
        super("My First Frame");
//------------------------------------------------------
// Create components: Jpanel, JLabel and JTextField
        String Filename;
        
        Filename = "THON_FootBallPlayer";
        px = new myJPanelx(Filename);

        Filename = "THON_Student";
        px = new myJPanelx(Filename);

        Filename = "THON_NittanyLion";
        px = new myJPanelx(Filename);

        Filename = "Football_FootBallPlayer";
        px = new myJPanelx(Filename);

        Filename = "Football_Student";
        px = new myJPanelx(Filename);

        Filename = "Football_NittanyLion";
        px = new myJPanelx(Filename);

        Filename = "Alumni_FootBallPlayer";
        px = new myJPanelx(Filename);

        Filename = "Alumni_Student";
        px = new myJPanelx(Filename);

        Filename = "Alumni_NittanyLion";
        px = new myJPanelx(Filename);

        
        Filename = "Trivia_THON_FootBallPlayer";
        px = new myJPanelx(Filename);

        Filename = "Trivia_THON_Student";
        px = new myJPanelx(Filename);

        Filename = "Trivia_THON_NittanyLion";
        px = new myJPanelx(Filename);

        Filename = "Trivia_Football_FootBallPlayer";
        px = new myJPanelx(Filename);

        Filename = "Trivia_Football_Student";
        px = new myJPanelx(Filename);

        Filename = "Trivia_Football_NittanyLion";
        px = new myJPanelx(Filename);

        Filename = "Trivia_Alumni_FootBallPlayer";
        px = new myJPanelx(Filename);

        Filename = "Trivia_Alumni_Student";
        px = new myJPanelx(Filename);

        Filename = "Trivia_Alumni_NittanyLion";
        px = new myJPanelx(Filename);
        
        Filename = "Rankings";
        px = new myJPanelx(Filename);

//------------------------------------------------------
// Choose a Layout for JFrame and 
// add Jpanel to JFrame according to layout     
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(px, "Center");
//------------------------------------------------------
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(550, 400);
        setVisible(true);
    }
//-------------------------------------------------------------------
}

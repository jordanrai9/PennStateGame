/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hrai36
 */
public class QuestionAnswer {
    private String Question;
    private String Answer1;
    private String Answer2;
    private String Answer3;
    private String Answer4;
    private int CorrectChoice;
    
    public QuestionAnswer(){
    }
    /**
     * @return the Question
     */
    public String getQuestion() {
        return Question;
    }

    /**
     * @param Question the Question to set
     */
    public void setQuestion(String Question) {
        this.Question = Question;
    }

    /**
     * @return the Answer1
     */
    public String getAnswer1() {
        return Answer1;
    }

    /**
     * @param Answer1 the Answer1 to set
     */
    public void setAnswer1(String Answer1) {
        this.Answer1 = Answer1;
    }

    /**
     * @return the Answer2
     */
    public String getAnswer2() {
        return Answer2;
    }

    /**
     * @param Answer2 the Answer2 to set
     */
    public void setAnswer2(String Answer2) {
        this.Answer2 = Answer2;
    }

    /**
     * @return the Answer3
     */
    public String getAnswer3() {
        return Answer3;
    }

    /**
     * @param Answer3 the Answer3 to set
     */
    public void setAnswer3(String Answer3) {
        this.Answer3 = Answer3;
    }

    /**
     * @return the Answer4
     */
    public String getAnswer4() {
        return Answer4;
    }

    /**
     * @param Answer4 the Answer4 to set
     */
    public void setAnswer4(String Answer4) {
        this.Answer4 = Answer4;
    }

    /**
     * @return the CorrectChoice
     */
    public int getCorrectChoice() {
        return CorrectChoice;
    }

    /**
     * @param CorrectChoice the CorrectChoice to set
     */
    public void setCorrectChoice(int CorrectChoice) {
        this.CorrectChoice = CorrectChoice;
    }
    
    
          
            
}

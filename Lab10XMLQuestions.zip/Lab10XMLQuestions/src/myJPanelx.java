
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.beans.*;

public class myJPanelx extends JPanel
{

    XML_240 x2;

    public myJPanelx(String Filename)
    {
        JButton b1 = new JButton("Check the xml file outside NetBeans to see its contents");
        add(b1);
//=====================================
        x2 = new XML_240(); // creates the 240 class that reads and writes XML
//=====================================
        System.out.println("I was here");
        String s1,s2,s3,s4,s5;
        int correctChoice;
        String r1,r2,r3;
        String t1,t2,t3;
        ScoreTime[] STarr = new ScoreTime[3];
        ScoreTime[] STarrtemp = new ScoreTime[3];
        
        x2.openWriterXML("XMLFiles/"+Filename);

        if (Filename.equals("THON_FootBallPlayer")) {
            
            // Question One
            s1 = " A food truck at the THON event sells salads for $6.50 each and drinks $2.00 each. The revenue from selling 209 salads in one day is $836.50. How many salads were sold that day?";
            s2 = "77";
            s3 = "93";
            s4 = "99";
            s5 = "105";
            correctChoice = 1;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "The recommended daily calcium intake for a healthy 20 year old at PSU to partake in THON is 1,000 milligrams (mg). One cup of milk contains 299 mg of calcium and one cup of juice contains 261 mg of calcium. Which of the following inequalities represents the possible number of cups of milk m and cups of juice j a 20-year-old could drink in a day to meet or exceed the recommended daily calcium intake from these drinks alone? ";
            s2 = "299m+261j>=1000";
            s3 = "299m+261j>1000";
            s4 = "299/m+261/j>=1000";
            s5 = "299/m+261/j>1000";
            correctChoice = 1;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("THON_NittanyLion")) {
            
            // Question One
            s1 = "The function p(x) represents the distance \n" +
"the nittany lion must sprint to reach the THON event. If the value of p(3) is -2, which of the following is true about p(x)?";
            s2 = "x-5 is a factor of p(x)";
            s3 = "x-2 is a factor of p(x)";
            s4 = "x+2 is a factor of p(x)";
            s5 = "The remainder when p(x) is divided by x-3 is -2";
            correctChoice = 4;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "A THON organizer randomly selected 75 PSU students from the list of all students enrolled in the IST program. She asked them, “How many minutes per day do you typically spend doing IST homework?” The mean reading time in the sample was 89 minutes, and the margin of error for this estimate was 4.28 minutes. Another THON organizer intends to replicate the survey and will attempt to get a smaller margin of error. Which of the following samples will most likely result in a smaller margin of error for the estimated mean time students in the IST program do homework per day?";
            s2 = "40 randomly selected IST program students";
            s3 = "40 randomly selected undergraduate students from all degree programs at PSU";
            s4 = "300 randomly selected IST program students";
            s5 = "300 randomly selected undergraduate students from all degree programs at PSU";
            correctChoice = 3;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("THON_Student")) {
            
            // Question One
            s1 = "A group of 20 PSU students plan on attending THON. Later, one student in the group cancels. The students leave at different times, and decide to divide themselves into 3 groups as evenly as possible to walk to the event.  How many students need to be in one group at least?";
            s2 = "5";
            s3 = "6";
            s4 = "7";
            s5 = "8";
            correctChoice = 2;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "A freshman is particpating in THON for the first time and needs to decide what to wear. She has two shirts, blue and green, three pants, red, yellow, and pink, and two pairs of socks, orange and purple. How many colorful outfits can she put together, if she needs to be wearing one shirt, one pair of pants and one pair of socks?";
            s2 = "6";
            s3 = "12";
            s4 = "24";
            s5 = "30";
            correctChoice = 2;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        
        
        
        if (Filename.equals("Football_FootBallPlayer")) {
            
            // Question One
            s1 = "In the equations b = 2.35+ 0.25x and c = 1.75+ 0.4x, b and c represent the price per pound of beef and chicken respectively for each x purchase of either beef or chicken burgers sold at the PSU football game. What is the price per pound of beef when it is equal to the price per pound of chicken?";
            s2 = "$2.60";
            s3 = "$2.85";
            s4 = "$2.95";
            s5 = "$3.35";
            correctChoice = 3;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "The PSU football team is staying at a hotel for an away game that charges $99.95 per night plus tax for a room. A tax of 8% is applied to the room rate, and an additional onetime untaxed fee of $5.00 is charged by the hotel. Which of the following represents the total charge for two football players in ONE room, in dollars, for staying x nights?";
            s2 = "(99.5 + 0.08x) + 5";
            s3 = "1.08(99.95x) + 5";
            s4 = "1.08(99.95x + 5)";
            s5 = "1.08(99.95 + 5)x";
            correctChoice = 2;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Football_NittanyLion")) {
            
            // Question One
            s1 = "For the football team and staff, there are 5 times as many right-handed players as there are left-handed players, and there are 9 times as many right-handed trainers as their left-handed trainers. If there are a total of 18 left-handed trainers and players and 122 right-handed players and trainers, which is closest to the probability that a right-handed player or trainer selected at random is a player?";
            s2 = "0.410";
            s3 = "0.357";
            s4 = "0.333";
            s5 = "0.250";
            correctChoice = 1;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "A manager from a sports gear company that provides equippment to PSU's football team estimated that the cost C, in dollars, of producing n helmets is C equals 7 n plus 350. The company sells each item for $12. The company makes a profit when total income from selling a quantity of helmets is greater than the total cost of producing that quantity of helmets. Which of the following inequalities gives all possible values of n for which the manager estimates that the company will make a profit?";
            s2 = "n<70";
            s3 = "n>84";
            s4 = "n>70";
            s5 = "n>84";
            correctChoice = 3;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Football_Student")) {
            
            // Question One
            s1 = "On the day of the football game, Armand sent m text messages each hour for 5 hours to his friends, and while Tyrone sent p text messages each hour for 4 hours.  Which represents the total number of text messages sent by Armand and Tyrone that day?";
            s2 = "9mp";
            s3 = "20mp";
            s4 = "5m+4p";
            s5 = "4m+5p";
            correctChoice = 3;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "Lisa wants to buy Penn State football T-Shirts at the online campus store, since she is an IST student. A shirt costs $5.00 and has there is a 6% tax rate in Pennsylvania. She wants her shirt to come the day of ordering, which is additional $4 after taxes. How much will Lisa spend? ";
            s2 = "$9.00";
            s3 = "$9.30";
            s4 = "$10.00";
            s5 = "$10.30";
            correctChoice = 2;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Alumni_FootBallPlayer")) {
            
            // Question One
            s1 = "A doctor from Penn State College of Medicine stores one type of medicine in 2 decagram containers  How many 1-milligram doses are there in one 2-decagram  container? 1 decagram = 10 grams & 1,000 milligrams =  1 gram";
            s2 = ".002";
            s3 = "200";
            s4 = "2000";
            s5 = "20000";
            correctChoice = 4;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "A PSU psychology researcher wanted to know if there is an association between exercise and sleep for the population of IST students in PSU. She obtained survey responses from a random sample of 2000 IST students and found convincing evidence of a positive association between exercise and sleep. Which of the following conclusions is well supported by the data?";
            s2 = "There is a positive association between exercise and sleep for IST students at PSU.";
            s3 = "There is a positive association between exercise and sleep for IST students in the world.";
            s4 = "Using exercise and sleep as defined by the study, an increase in sleep is caused by an increase of exercise for IST students in PSU.";
            s5 = "Using exercise and sleep as defined by the study, an increase in sleep is caused by an increase of exercise for IST students in PSU.";
            correctChoice = 1;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Alumni_NittanyLion")) {
            
            // Question One
            s1 = "A NASA physicist from Penn State studies mechanics.   The equation h = -4.9t^2+ 25t expresses the approximate height, h, in meters, of a ball t seconds after it is launched vertically upward from the ground with an initial velocity of 25 meters/sec. After approximately how many seconds will the ball hit the ground?";
            s2 = "3.5";
            s3 = "4";
            s4 = "4.5";
            s5 = "5";
            correctChoice = 3;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "A PSU biologist predicted that a local population of animals will double in size every 12 years. The population at the beginning of 2014 was estimated to be 50 animals. If P represents the population n years after 2014, then which of the following equations represents the model of the population over time?";
            s2 = "P = 12 + 50n";
            s3 = "P = 50 + 12n";
            s4 = "P = 50 (2)^ 12n";
            s5 = "P = 50 (2)^ (n/12)";
            correctChoice = 4;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Alumni_Student")) {
            
            // Question One
            s1 = "A medical researcher from PSU uses a model, h = 3a+ 28.6, to estimate the height, h, of a boy, in inches in terms of the boy's age, a, in years, for boys between the ages of 2 and 5. Based on the model, what is the estimated increase, in inches, of a boy's height each year?";
            s2 = "3";
            s3 = "5.7";
            s4 = "9.5";
            s5 = "14.3";
            correctChoice = 1;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "A PSU primal researcher finds that the mean age of all the male primates is 15 years, and the mean age of all female primates is 19 years. Which of the following must be true about the mean age m of the combined group of male and female primates?";
            s2 = "m=17";
            s3 = "m>17";
            s4 = "m<17";
            s5 = "15<m<19";
            correctChoice = 4;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        
        /*   *************
        
        TRIVIA GAME 
        
        **************************/
        
        if (Filename.equals("Trivia_THON_FootBallPlayer")) {
            
            // Question One
            s1 = "What year was THON first organized? ";
            s2 = "1973";
            s3 = "1975";
            s4 = "1980";
            s5 = "1985";
            correctChoice = 1;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "What is the purpose of THON? ";
            s2 = "to raise money and provide support to children and their families battling pediatric cancer. ";
            s3 = "to donate money to the Make A Wish foundation";
            s4 = "to raise awareness about mental health issues";
            s5 = "to provide relief and support to those affected by natural disasters";
            correctChoice = 1;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Trivia_THON_NittanyLion")) {
            
            // Question One
            s1 = "In the first THON event, 78 dancers participated in the Dance Marathon which was held in Penn State's HUB Ballroom. How long did it last, and how much money was made?";
            s2 = "28 hours, $1,000";
            s3 = "28 hours, $2,000";
            s4 = "30 hours, $1,000";
            s5 = "30 hours, $2,000";
            correctChoice = 2;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "How many dancers and how many organizers partake in THON, besides Penn State students?";
            s2 = "700 dancers, more than 15,000 organizers";
            s3 = "700 dancers, 15,000 organizers";
            s4 = "800 dancers, more than 17,000 organizers";
            s5 = "800 dancers, 17,000 organizers";
            correctChoice = 1;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Trivia_THON_Student")) {
            
            // Question One
            s1 = "THON is the _____ largest student-run organization in the world";
            s2 = "first";
            s3 = "second";
            s4 = "third";
            s5 = "fourth";
            correctChoice = 1;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "What is the rallying cry at the THON event?";
            s2 = "Beat Cancer!";
            s3 = "For the Kids";
            s4 = "We Are!";
            s5 = "There is not motto";
            correctChoice = 2;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        
        
        
        if (Filename.equals("Trivia_Football_FootBallPlayer")) {
            
            // Question One
            s1 = "The Nittany Lions play their home games at what stadium located in University Park, Pennsylvania?";
            s2 = "Darrel K Royal Stadium";
            s3 = "Beaver Stadium";
            s4 = "Bryant-Denny Stadium";
            s5 = "Kinnick Stadium";
            correctChoice = 2;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "When did the Nittany Lions join the Big Ten Conference?";
            s2 = "1990";
            s3 = "1991";
            s4 = "1992";
            s5 = "1993";
            correctChoice = 4;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Trivia_Football_NittanyLion")) {
            
            // Question One
            s1 = "Under head coach Joe Paterno, the Nittany Lions has a perfect 12-0 season and won the Fiesta Bowl for that national championship. What year did they win this title?";
            s2 = "1980";
            s3 = "1982";
            s4 = "1984";
            s5 = "1986";
            correctChoice = 1;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "Hugo Bezdek was Penn State's first football director. How many seasons was he present?";
            s2 = "9";
            s3 = "10";
            s4 = "11";
            s5 = "12";
            correctChoice = 4;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Trivia_Football_Student")) {
            
            // Question One
            s1 = "The Penn State Nittany Lions compete in the NCAA Division I Football Bowl Subdivision of what conference?";
            s2 = "Big Ten";
            s3 = "Pac 12";
            s4 = "Sun Belt";
            s5 = "American Athletic";
            correctChoice = 1;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "Who was the first head coach for the Nittany Lions?";
            s2 = "George Hoskins";
            s3 = "Daniel Reed ";
            s4 = "Tom Fulton";
            s5 = "Jack Hollenback";
            correctChoice = 1;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Trivia_Alumni_FootBallPlayer")) {
            
            // Question One
            s1 = "Penn State Alum Mark Parker was a champion runner for Penn State's team and has been Nike's CEO since 2006. What year did he graduate?";
            s2 = "1975";
            s3 = "1977";
            s4 = "1980";
            s5 = "1982";
            correctChoice = 1;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "Which Penn State alum earned his BA in Fine Arts and is a soap opera actor, but most notably know for his actress daughter, Jennifer Aniston?";
            s2 = "John Aniston";
            s3 = "Tim Aniston";
            s4 = "Steve Aniston";
            s5 = "Andrew Aniston";
            correctChoice = 1;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Trivia_Alumni_NittanyLion")) {
            
            // Question One
            s1 = "Jef Raskin completed his master's degree in computer science at Penn State in 1967. He was one of Apple's first employees and wanted to create a computer that was easier for people to use. What was he nicknamed?";
            s2 = "The Father of Apple";
            s3 = "The Father of MacBook";
            s4 = "The Founder of MacBook";
            s5 = "The Father of Macintosh";
            correctChoice = 2;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "A famous Penn alum was a running back for the Nittany Lions and helped the team achieve its 12-0 season in 1973. He majored in law enforcement and corrections. He is the only Penn State football player to have his number retired." +
                 "He is Penn State’s only Heisman Trophy winner, and he went on to play for the Los Angeles Rams and later the San Diego Chargers. What was his name?";
            s2 = "Alex McCurry";
            s3 = "Doug Flutie";
            s4 = "John Cappelletti";
            s5 = "Joshua Newton";
            correctChoice = 3;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if (Filename.equals("Trivia_Alumni_Student")) {
            
            // Question One
            s1 = "Which famous writer and producer of films like Step Brothers, Anchorman: The Legend of Ron Burgundy, and others attended Penn State?";
            s2 = "Adam McKay";
            s3 = "Michael Bay";
            s4 = "Quentin Tarantino";
            s5 = "Wes Anderson";
            correctChoice = 1;
            
            QuestionAnswer QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        
            // Question 2
            s1 = "Which famous PSU alum now stars as Phil Dunphy on Modern Family?";
            s2 = "Ty Burrell";
            s3 = "Leonardo DiCaprio";
            s4 = "Will Smith";
            s5 = "Tom Allen";
            correctChoice = 1;
            QA = new QuestionAnswer();
            QA.setQuestion(s1);
            QA.setAnswer1(s2);
            QA.setAnswer2(s3);
            QA.setAnswer3(s4);
            QA.setAnswer4(s5);
            QA.setCorrectChoice(correctChoice);
            x2.writeObject(QA);
        }
        
        if(Filename.equals("Rankings")){
            
            ScoreTime ST1 = new ScoreTime();
            ST1.setRanking("0");
            ST1.setTime("8:00");
            System.out.println("Here from ranking");
            x2.writeObject(ST1);
            ST1 = new ScoreTime();
            ST1.setRanking("0");
            ST1.setTime("9:00");
             System.out.println("Here from ranking1");
            x2.writeObject(ST1);
            ST1 = new ScoreTime();
             ST1.setRanking("0");
            ST1.setTime("9:30");
             System.out.println("Here from ranking2");
            x2.writeObject(ST1);
            
            x2.closeWriterXML();
        
            
            
            int finalScore = 0;
            int time = 8;
            
            x2.openReaderXML("XMLFiles/"+Filename);
            
            STarr[0] = new ScoreTime();
            //STarr[0].setRanking("1");
            //STarr[0].setTime("8:00");
            System.out.println(x2);
            System.out.println(STarr[0]);
            STarr[0] = (ScoreTime) x2.ReadObject();
            System.out.println("First Object" + STarr[0].getRanking() + STarr[0].getTime());
            
            STarr[1] = new ScoreTime();
           // STarr[1].setRanking("2");
           // STarr[1].setTime("8:30");
            STarr[1] = (ScoreTime) x2.ReadObject();
            System.out.println("First Object" + STarr[1].getRanking() + STarr[1].getTime());
            
            STarr[2] = new ScoreTime();
            //STarr[2].setRanking("3");
            //STarr[2].setTime("9:00");
            STarr[2] = (ScoreTime) x2.ReadObject();
            System.out.println("First Object" + STarr[2].getRanking() + STarr[2].getTime());
            
            x2.closeReaderXML();
            
            STarrtemp[0] = new ScoreTime();
            STarrtemp[1] = new ScoreTime();
            STarrtemp[2] = new ScoreTime();
            
            
            if(finalScore >= Integer.parseInt(STarr[0].getRanking())){
                STarrtemp[0].setRanking(Integer.toString(finalScore));
                STarrtemp[0].setTime(Integer.toString(time));
                STarrtemp[1].setRanking(STarr[0].getRanking());
                STarrtemp[1].setTime(STarr[0].getTime());
                STarrtemp[2].setRanking(STarr[1].getRanking());
                STarrtemp[2].setTime(STarr[1].getTime());
                               

                }
            else if((finalScore >= Integer.parseInt(STarr[1].getRanking())) &&
            (finalScore < Integer.parseInt(STarr[0].getRanking()))){
                STarrtemp[0].setRanking(STarr[0].getRanking());
                STarrtemp[0].setTime(STarr[0].getTime());
                STarrtemp[1].setRanking(Integer.toString(finalScore));
                STarrtemp[1].setTime((Integer.toString(time)));
                STarrtemp[2].setRanking(STarr[1].getRanking());
                STarrtemp[2].setTime(STarr[1].getTime());
                

            }
            else if((finalScore >= Integer.parseInt(STarr[2].getRanking())) && 
            (finalScore < Integer.parseInt(STarr[1].getRanking()))){
                STarrtemp[0].setRanking(STarr[0].getRanking());
                STarrtemp[0].setTime(STarr[0].getTime());
                STarrtemp[1].setRanking(STarr[1].getRanking());
                STarrtemp[1].setTime(STarr[1].getTime());
                STarrtemp[2].setRanking(Integer.toString(finalScore));
                STarrtemp[2].setTime((Integer.toString(time)));
            }
            else /*(finalScore < Integer.parseInt(STarr[2].getRanking()))*/{
                STarrtemp[0].setRanking(STarr[0].getRanking());
                STarrtemp[0].setTime(STarr[0].getTime());
                STarrtemp[1].setRanking(STarr[1].getRanking());
                STarrtemp[1].setTime(STarr[1].getTime());
                STarrtemp[2].setRanking(STarr[2].getRanking());
                STarrtemp[2].setTime(STarr[2].getTime());
            }
            
            for (int i=0; i<=2; i++){
                System.out.println(i + "object");
                System.out.println("ranking" + STarrtemp[i].getRanking());
                System.out.println("time" + STarrtemp[i].getTime());
                
            }
            
            //x2.openWriterXML(Filename);
            
            
            
            
            //insert new value into array
            /*public int orderRank (int intSorted[], int first, int last, int insertedScore){
                
                int i = last;
                while ((int i > first) && (insertedScore < intSorted[i-1])){
               
                intSorted[i] = intSorted[i-1];
                i = i-1;
            }
                intSorted[i] = insertedScore;
                return i;
            }   
                //perform bubble sort
            for (int j = 0; j < intSorted.length;j++){
                    bubbleSort(intSorted);
                } */
        
           /* public int[] insertionSort (int intSorted[]){
                 int temp;
                    for (int i = 1; i < intSorted.length; i++) {
                        for(int j = i ; j > 0 ; j--){
                            if(intSorted[j] < intSorted[j-1]){
                                temp = intSorted[j];
                                intSorted[j] = intSorted[j-1];
                                intSorted[j-1] = temp;
                            }
                        }
                    }
                    return intSorted;
            }
           int[] intSorted.reverse();*/
            //order new array into descending order using bubble sort
    }

        
        
        
        //x2.closeWriterXML();
       
  /*
        s1 = "Question 3";
        s2 = "Answer 1";
        s3 = "Answer 2";
        s4 = "Answer 3";
        s5 = "Answer 4";
        correctChoice = 1;
        
        QA = new QuestionAnswer();
        QA.setQuestion(s1);
        QA.setAnswer1(s2);
        QA.setAnswer2(s3);
        QA.setAnswer3(s4);
        QA.setAnswer4(s5);
        QA.setCorrectChoice(correctChoice);
        x2.writeObject(QA);
        x2.closeWriterXML();
        */
        
        //these statements above just open an xml file, wrote 3 lines in the file, close it.
        //open the xml file outside Netbeans and check the contents
        
        /*
        x2.openReaderXML("XMLFiles/"+Filename);
        QuestionAnswer QA2 = (QuestionAnswer) x2.ReadObject();
        System.out.println(QA2.getQuestion());
        System.out.println(QA2.getAnswer1());
        System.out.println(QA2.getAnswer2());
        System.out.println(QA2.getAnswer3());
        System.out.println(QA2.getAnswer4());
        System.out.println(QA2.getCorrectChoice());
        
        x2.closeReaderXML();
        */
        
       /* System.out.println("I was here before write");
       // x2.openWriterXML("XMLFiles/"+Filename);
      //  x2.writeObject(QA);
        
       
        System.out.println("I was here after write");
        x2.closeWriterXML();
        //these statements above just open an xml file, wrote 3 lines in the file, close it.
        //open the xml file outside Netbeans and check the contents

     */
    }

}
